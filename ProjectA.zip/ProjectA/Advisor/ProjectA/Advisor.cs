﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Advisor
{
    public partial class Form4 : Form
    {
     

        public Form4()
        {
            InitializeComponent();

            comboBoxGender.Items.Add("Male");
            comboBoxGender.Items.Add("Female");
            comboBoxDesignation.Items.Add("Professor");
            comboBoxDesignation.Items.Add("Associate Professor");
            comboBoxDesignation.Items.Add("Assisstant Professor");
            comboBoxDesignation.Items.Add("Lecturer");
            comboBoxDesignation.Items.Add("Industry Professional");

        
        }
        //SQL Connection for database

        SqlConnection conn = new SqlConnection(@"Data Source=SABANOOR\SABA;Initial Catalog=ProjectA;Integrated Security=True; MultipleActiveResultSets = True");


        //Display Data in the Gridview
        private void Display_Data()
        {
            if (conn.State == ConnectionState.Closed)
            {
                //Connection Open
                conn.Open();
            }
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select  Person.Id,Person.FirstName , Person.LastName , Person.Contact , Person.Email ,Person.DateOfBirth , Person.Gender , Advisor.Designation , Advisor.Salary from Person join Advisor On Person.Id = Advisor.Id";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter dataadp = new SqlDataAdapter(cmd);
            dataadp.Fill(dt);
            dataGridView1.DataSource = dt;
            //Connection close
            conn.Close();
        }

        //Save Button in which we can insert a data 
        private void btnSave_Click(object sender, EventArgs e)
        {
            //Connection open
            conn.Open();




            string congo = comboBoxGender.SelectedItem.ToString();

            string genderValue = "select Id FROM Lookup WHERE Category = 'Gender' AND value ='" + congo + "'";
            SqlCommand genderInt = new SqlCommand(genderValue, conn);
            int value = 0;
            SqlDataReader reader = genderInt.ExecuteReader();
            // genderInt.ExecuteNonQuery();
            while (reader.Read())
            {

                value = int.Parse(reader[0].ToString());
            }



            string per = "INSERT into Person(FirstName , LastName , Contact , Email , DateOfBirth , Gender) values ('" + textBox1.Text + "' , '" + TextBox2.Text + "' , '" + TextBox3.Text + "' , '" + TextBox5.Text + "' , '" + DateTime.Now( ) + "' , '" + value + "') ";

            SqlCommand persi = new SqlCommand(per, conn);
            int ii = persi.ExecuteNonQuery();
            int value1 = 0;
            string query = "Select Id from Person where (Id = SCOPE_IDENTITY())";
            SqlCommand cmd = new SqlCommand(query, conn);
            var val = cmd.ExecuteScalar().ToString();
            value1 = int.Parse(val);
            string congo1 = comboBoxDesignation.Text.ToString();
            string desg = "select Id FROM Lookup WHERE Category = 'DESIGNATION' AND Value ='" + congo1 + "'";
            SqlCommand d = new SqlCommand(desg, conn);
            int value5 = 0;
            SqlDataReader reader1 = d.ExecuteReader();
            // genderInt.ExecuteNonQuery();
            while (reader1.Read())
            {
                value5 = int.Parse(reader1[0].ToString());
            }
            string q = "insert into Advisor values('" + value1 + "','" + value5 + "' , '" + int.Parse(TextBox6.Text.ToString()) + "' )";
            SqlCommand cmd1 = new SqlCommand(q, conn);
            int ji = cmd1.ExecuteNonQuery();
            if (MessageBox.Show("Do You want to Register it", "Register", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MessageBox.Show("Student is registered");
            }
            else
            {
                MessageBox.Show("Student not registered", "Register Again", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            Display_Data();
            //Connection Close
            conn.Close();

        }

        //Display button in which we show a data
        private void btnDisplaydata_Click(object sender, EventArgs e)
        {
            Display_Data();
        }

        //Delete button in which we delete a name and value in a row
        private void btnDelete_Click(object sender, EventArgs e)
        {

            //Connection Open
            conn.Open();
            string ID = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            string delete = "DELETE FROM Advisor WHERE Id = '" + int.Parse(ID) + "'";
            SqlCommand del = new SqlCommand(delete, conn);
            if (MessageBox.Show("Do You want to delete it", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                del.ExecuteNonQuery();
                del.CommandText = string.Format("DELETE from Person where  Id ='" + int.Parse(ID) + "'");
                del.ExecuteNonQuery();
                dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
                MessageBox.Show("DATA IS DELETED");
            }
            else
            {
                MessageBox.Show("Row not deleted", "Remove row", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //Connection Close

            conn.Close();
        }

        //Update button in which we update a name and value in a row


        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //Connection OPen
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }

            string genderValue = "select Id FROM Lookup WHERE Category = 'GENDER' AND value ='" + comboBoxGender.Text.ToString() + "'";
            SqlCommand genderInt = new SqlCommand(genderValue, conn);
            int value = 0;
            SqlDataReader reader = genderInt.ExecuteReader();
            // genderInt.ExecuteNonQuery();
            while (reader.Read())
            {
                value = int.Parse(reader[0].ToString());
            }
            //FirstName ='" + textBox2.Text + "' ,
            string query = string.Format("SELECT Id from Person Where Email = '" + TextBox5.Text + "'");
            SqlCommand cmd = new SqlCommand(query, conn);
            var val = cmd.ExecuteScalar().ToString();
            int value1 = int.Parse(val);
            // int id =int.Parse( cmd.ExecuteScalar());
            string per = "Update Person set FirstName ='" + textBox1.Text + "' ,  LastName= '" + TextBox2.Text + "' , Contact = '" + TextBox3.Text + "', Email = '" + TextBox5.Text + "', DateOfBirth ='" + DateTime.Parse(TextBox4.Text) + "', Gender = '" + value + "' WHERE Id= '" + value1 + "'";
            SqlCommand persi = new SqlCommand(per, conn);
            int i = persi.ExecuteNonQuery();
            string congo1 = comboBoxDesignation.Text.ToString();
            string desg = "select Id FROM Lookup WHERE Category = 'DESIGNATION' AND Value ='" + congo1 + "'";
            SqlCommand d = new SqlCommand(desg, conn);
            int value5 = 0;
            SqlDataReader reader1 = d.ExecuteReader();
            // genderInt.ExecuteNonQuery();
            while (reader1.Read())
            {
                value5 = int.Parse(reader1[0].ToString());
            }
            string st = "Update Advisor set Designation = '" + value5 + "',Salary = '" + int.Parse(TextBox6.Text) + "' where Id ='" + value1 + "'";
            SqlCommand persi1 = new SqlCommand(st, conn);
            //int j = persi1.ExecuteNonQuery();

            //Error message show
            if (MessageBox.Show("Do You want to Update it", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MessageBox.Show("DATA IS Updated");
            }
            else
            {
                MessageBox.Show("Row not Updated", "Update row", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            //Connection Close
            conn.Close();
            Display_Data();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Advisor.Project_Advisor f3 = new Advisor.Project_Advisor();
            this.Show();
            f3.ShowDialog();
            this.Close();
        }
    }
    }


    

