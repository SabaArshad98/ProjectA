﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using itextSharp.text;
using System.iTextSharp.pdf.text;
using System.IO;

namespace Advisor 
{
    public partial class PDF_File : Form
    {
        public PDF_File()
        {
            InitializeComponent();
        }

        private void btngeneratepdffile_Click(object sender, EventArgs e)
        {
            Document doc = new Document(PageSize.A4);
            //var output =new fiIeStream ( saveFileDialog.MapPath ( ''MyFirstPDF.pdf''


            doc.Open();

            PdfFilePTable table1 = new PdfPTable(2);
            table1.DefaultCell.Border = 0;
            table1.WidthPercentage = 80;
            PdfPCell cell11 = new PdfPCell();
            cell11.Colpsan = 1;
            cell11.AddElement(new Pragraph("datagridview"));
            cell11.VerticalAlignment = DataGridViewElement.ALIGN_LEFT;
            PdfPCell cell12 = new PdfPCell();
            cell11.VerticalAlignment = Element.ALIGN_CENTER;
            table1.AddCell(cell11);
            table1.AddCell(cell12);



        } 
    }
}
