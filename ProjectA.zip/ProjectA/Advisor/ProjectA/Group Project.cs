﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Advisor
{
    public partial class Group_Project : Form
    {
        public Group_Project()
        {
            InitializeComponent();
      

            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select * from [dbo].[Project ]", conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBoxprojectid.Items.Add("");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string s = dt.Rows[i]["Id"].ToString();
                string s2 = s;
                comboBoxprojectid.Items.Add("");
            }
            conn.Close();


            conn.Open();
            SqlDataAdapter db = new SqlDataAdapter("Select * from [dbo].[Group]", conn);
            DataTable dt2 = new DataTable();
            db.Fill(dt2);
            comoboxgroupid.Items.Add("");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string s = dt2.Rows[i]["Id"].ToString();
                string s2 = s;
                comoboxgroupid.Items.Add("");
            }
            conn.Close();


        }

        SqlConnection conn = new SqlConnection(@"Data Source=SABANOOR\SABA;Initial Catalog=ProjectA;Integrated Security=True; MultipleActiveResultSets = True");



        private void btnsave_Click(object sender, EventArgs e)
        {
            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT into  Group Project(Project ID, Group ID , Assignment Date) values ('" + comboBoxprojectid.Text + "' , '" + comoboxgroupid.Text + "' ,  '" + txtassignmentdate.Text + "')";
            cmd.ExecuteNonQuery();
            conn.Close();
            comoboxgroupid.Text = "";
            comboBoxprojectid.Text = "";
            txtassignmentdate.Text = "";


            Display_Data();
            MessageBox.Show("Data Inserted");
            //Connection Close
            conn.Close();
        }
        private void Display_Data()
        {
            //Connection Open

            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "select * from Project";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter dataadp = new SqlDataAdapter(cmd);
            dataadp.Fill(dt);
            dataGridView1.DataSource = dt;
            //Connection Close
            Display_Data();
            conn.Close();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Display_Data();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "DELETE from  Group Project where  Project ID ='" + comboBoxprojectid.Text + "'";
            if (MessageBox.Show("Do You want to delete it", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MessageBox.Show("DATA IS DELETED");
            }
            else
            {
                MessageBox.Show("Row not deleted", "Remove row", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            cmd.ExecuteNonQuery();
            comboBoxprojectid.Text = "";
            comoboxgroupid.Text = "";
            txtassignmentdate.Text = "";
            Display_Data();
            //Connection Close
            conn.Close();
        }
    }
}
