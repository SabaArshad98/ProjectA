﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Advisor
{
    public partial class FYP_Database_Mangement_System : Form
    {
        public FYP_Database_Mangement_System()
        {
            InitializeComponent();
        }

        //Student Mangement form liking button
        private void btnStuMang_Click(object sender, EventArgs e)
        { 

         
         
                Student.Student f1 = new Student.Student();
                this.Show();
                f1.ShowDialog();
                this.Close();

            }

        //Advisor Mangement form liking button
        private void btnAdvisor_Click(object sender, EventArgs e)
        {

            Advisor.Form4 f4 = new Advisor.Form4();
            this.Show();
            f4.ShowDialog();
            this.Close();
        }

        //Project Mangement form liking button
        private void btnProject_Click(object sender, EventArgs e)
        {

           Project.Project f3 = new Project.Project();
                this.Show();
                f3.ShowDialog();
                this.Close();
            }

        //Evaluation Mangement form liking button
        private void btnEvaluation_Click(object sender, EventArgs e)
        {
        Evaluation.form4 f5 = new Evaluation.form4();
                this.Show();
                f5.ShowDialog();
                this.Close();
            }

       
    }
    }


