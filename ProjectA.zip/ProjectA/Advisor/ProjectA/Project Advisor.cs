﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Advisor
{
    public partial class Project_Advisor : Form
    {
        public Project_Advisor()
        {
            InitializeComponent();
            comboBoxadvisorid.Items.Add("Advisor Id");
            comboBoxadvisorid.Items.Add("Group Id");
            comboBoxadvisorid.Items.Add("Project Id");
            comboBoxadvisorid.Items.Add("Student Id");
            comboBoxadvisorid.Items.Add("Evaluation Id");
            comboBoxprojectid.Items.Add("Advisor Id");
            comboBoxprojectid.Items.Add("Group Id");
            comboBoxprojectid.Items.Add("Project Id");
            comboBoxprojectid.Items.Add("Student Id");
            comboBoxprojectid.Items.Add("Evaluation Id");
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select * from [dbo].[Advisor ]", conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBoxadvisorid.Items.Add("");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string s = dt.Rows[i]["Id"].ToString();
                string s2 = s;
                comboBoxadvisorid.Items.Add("");
            }
            conn.Close();


            conn.Open();
            SqlDataAdapter db = new SqlDataAdapter("Select * from [dbo].[Project]", conn);
            DataTable dt1 = new DataTable();
            db.Fill(dt1);
            comboBoxprojectid.Items.Add("");
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                string s = dt1.Rows[i]["Id"].ToString();
                string s2 = s;
                comboBoxprojectid.Items.Add("");
            }
            conn.Close();

        }

        SqlConnection conn = new SqlConnection(@"Data Source=SABANOOR\SABA;Initial Catalog=ProjectA;Integrated Security=True;  MultipleActiveResultSets = True");

        private void Display_Data()
        {
            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            //join Student ON Person.Id = Student.Id
            //join Student ON Person.Id = Student.Id
            //, Student.RegistrationNo
            cmd.CommandText =  "select* from ProjectAdvisor"; 
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter dataadp = new SqlDataAdapter(cmd);
            dataadp.Fill(dt);
            dataGridView1.DataSource = dt;
            //Connection Close
            conn.Close();
        }


        private void btndisplaydata_Click(object sender, EventArgs e)
        {

            Display_Data();
        }
        private void btnsave_Click(object sender, EventArgs e)
        {

            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "INSERT into Project Advisor(Advisor Role , Assignment Date) values ('" + txtadvisorrole.Text + "' , '" + txtassignmentdate.Text + "' , '" + "')";
            if (MessageBox.Show("Do You want to Insert it", "Register", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MessageBox.Show("Data inserted");
            }
            else
            {
                MessageBox.Show("Data is not inserted", "Try Again", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            cmd.ExecuteNonQuery();
            //Connection Close
            conn.Close();
            txtadvisorrole.Text = "";
            txtassignmentdate.Text = "";
            Display_Data();
            MessageBox.Show("Data Inserted");
        }

        private void btndelete_Click(object sender, EventArgs e)
        {

            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "DELETE from Project Advisor  where  Advisor Role ='" + txtadvisorrole.Text + "'";
            if (MessageBox.Show("Do You want to delete it", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                MessageBox.Show("DATA IS DELETED");
            }
            else
            {

                MessageBox.Show("Row not deleted", "Remove row", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            cmd.ExecuteNonQuery();


            //Connection Close
            conn.Close();
            txtadvisorrole.Text = "";
            txtassignmentdate.Text = "";
            Display_Data();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            //Connection open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Update Project Advisor set  Advisor Role  = '" + this.txtadvisorrole.Text + "' ,Assignment Date = '" + this.txtassignmentdate.Text  + "' where Advisor Role = '" + this.txtadvisorrole.Text + "'";
            if (MessageBox.Show("Do You want to Update it", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                MessageBox.Show("DATA IS Updated");
            }
            else
            {

                MessageBox.Show("Row not Updated", "Update row", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            cmd.ExecuteNonQuery();
            //Connection Close
            conn.Close();
            txtadvisorrole.Text = "";
            txtassignmentdate.Text = "";
            Display_Data();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Project_Advisor_Load(object sender, EventArgs e)
        {

        }
    }
}
