﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Advisor
{
    public partial class GroupEvaluation : Form
    {
        public GroupEvaluation()
        {
            InitializeComponent();
            


            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select * from [dbo].[Group ]", conn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBoxgroupid.Items.Add("");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string s = dt.Rows[i]["Id"].ToString();
                string s2 = s;
                comboBoxgroupid.Items.Add("");
            }
            conn.Close();


            conn.Open();
            SqlDataAdapter db = new SqlDataAdapter("Select * from [dbo].[Evaluation]", conn);
            DataTable dt1 = new DataTable();
            db.Fill(dt1);
            comboBoxevaluationid.Items.Add("");
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                string s = dt1.Rows[i]["Id"].ToString();
                string s2 = s;
                comboBoxevaluationid.Items.Add("");
            }
            conn.Close();

        }

        //SQL Connection for database 
        SqlConnection conn = new SqlConnection(@"Data Source=SABANOOR\SABA;Initial Catalog=ProjectA;Integrated Security=True; MultipleActiveResultSets = True");

        
        private void btnsave_Click(object sender, EventArgs e)
        {

            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "INSERT into Group Evaluation(Total Marks ,Obtained Marks, Evaluation Date) values ('" + txttotalmarks.Text + txtobtainedmarks.Text + "' , '" + txtevaluationdate.Text +  "')";
            if (MessageBox.Show("Do You want to Insert it", "Register", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MessageBox.Show("Data inserted");
            }
            else
            {
                MessageBox.Show("Data is not inserted", "Try Again", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            cmd.ExecuteNonQuery();
            //Connection Close
            conn.Close();
            txttotalmarks.Text = "";
            txtobtainedmarks.Text = "";
            txtevaluationdate.Text = "";
            Display_Data();
            MessageBox.Show("Data Inserted");


        }
        //Display a Data in the Gridview
        private void Display_Data()
        {

            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "select * from GroupEvaluation";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter dataadp = new SqlDataAdapter(cmd);
            dataadp.Fill(dt);
            dataGridView1.DataSource = dt;
            //Connection Close
            conn.Close();

        }

        private void btndisplaydata_Click(object sender, EventArgs e)
        {

            Display_Data();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "DELETE from Group Evaluation where  Obtained Marks ='" + txtobtainedmarks.Text + "'";
            if (MessageBox.Show("Do You want to delete it", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                MessageBox.Show("DATA IS DELETED");
            }
            else
            {

                MessageBox.Show("Row not deleted", "Remove row", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            cmd.ExecuteNonQuery();


            //Connection Close
            conn.Close();
            txttotalmarks.Text = "";
            txtobtainedmarks.Text = "";
            txtevaluationdate.Text = "";
            Display_Data();

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            //Connection open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Update Group Evaluation set  Obtained Marks = '" + this.txtobtainedmarks.Text + "' , Evalation Date = '" + this.txtevaluationdate.Text  + "' where Obtained Marks = '" + this.txtobtainedmarks.Text + "'";
            if (MessageBox.Show("Do You want to Update it", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                MessageBox.Show("DATA IS Updated");
            }
            else
            {

                MessageBox.Show("Row not Updated", "Update row", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            cmd.ExecuteNonQuery();
            //Connection Close
            conn.Close();
            txttotalmarks.Text = "";
            txtobtainedmarks.Text = "";
            txtevaluationdate.Text = "";
            Display_Data();

        }

      
    }
}
