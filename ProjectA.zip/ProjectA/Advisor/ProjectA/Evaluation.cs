﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;


namespace Evaluation
{
    public partial class form4 : Form
    {
        public form4()
        {
            InitializeComponent();
            comboBoxid.Items.Add("Group Id");
            comboBoxid.Items.Add("Project Id");
            comboBoxid.Items.Add("Student Id");
            comboBoxid.Items.Add("Evaluation Id");
            comboBoxid.Items.Add("Advisor Id");
            
            conn.Open();
            SqlDataAdapter db = new SqlDataAdapter("Select * from [dbo].[Lookup]", conn);
            DataTable dt1 = new DataTable();
            db.Fill(dt1);
            comboBoxid.Items.Add("");
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                string s = dt1.Rows[i]["Id"].ToString();
                string s2 = s;
                comboBoxid.Items.Add("");
            }
            conn.Close();
        }

        //SQL Connection for database 
        SqlConnection conn = new SqlConnection(@"Data Source=SABANOOR\SABA;Initial Catalog=ProjectA;Integrated Security=True; MultipleActiveResultSets = True");

        public int rowsaffected { get; private set; }


        //Save Button in Which we can insert a data
        private void btnSave_Click(object sender, EventArgs e)
        {

            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "INSERT into Evaluation(Name, TotalMarks , TotalWeightage) values ('" + txtName.Text + "' , '" + txttotalmarks.Text + "' , '" + txtTotalweightage.Text + "')";
            if (MessageBox.Show("Do You want to Insert it", "Register", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MessageBox.Show("Data inserted");
            }
            else
            {
                MessageBox.Show("Data is not inserted", "Try Again", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            cmd.ExecuteNonQuery();
            //Connection Close
            conn.Close();
            txtName.Text = "";
            txttotalmarks.Text = "";
            txtTotalweightage.Text = "";
            Display_Data();
            MessageBox.Show("Data Inserted");

        }



        //Display a Data in the Gridview
        private void Display_Data()
        {

            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "select * from Evaluation";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter dataadp = new SqlDataAdapter(cmd);
            dataadp.Fill(dt);
            dataGridView1.DataSource = dt;
            //Connection Close
            conn.Close();

        }

        //Display button in which we show a data
        private void btnDisplaydata_Click(object sender, EventArgs e)
        {

            Display_Data();
        }


        //Delete Button in which we can delete a data in the row
        private void Delete_Click(object sender, EventArgs e)
        {

            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "DELETE from Evaluation where  Name ='" + txtName.Text + "'";
            if (MessageBox.Show("Do You want to delete it", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                MessageBox.Show("DATA IS DELETED");
            }
            else
            {

                MessageBox.Show("Row not deleted", "Remove row", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            cmd.ExecuteNonQuery();


            //Connection Close
            conn.Close();
            txtName.Text = "";
            txttotalmarks.Text = "";
            txtTotalweightage.Text = "";
            Display_Data();


        }

        //Update button in which we can update a name and value in a row
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //Connection open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Update Evaluation set  Name = '" + this.txtName.Text + "' ,TotalMarks = '" + this.txttotalmarks.Text + "' ,TotalWeightage= '" + this.txtTotalweightage.Text + "' where Name = '" + this.txtName.Text + "'";
            if (MessageBox.Show("Do You want to Update it", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                MessageBox.Show("DATA IS Updated");
            }
            else
            {

                MessageBox.Show("Row not Updated", "Update row", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            cmd.ExecuteNonQuery();
            //Connection Close
            conn.Close();
            txtName.Text = "";
            txttotalmarks.Text = "";
            txtTotalweightage.Text = "";
            Display_Data();
            
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Advisor.GroupEvaluation f7 = new Advisor.GroupEvaluation();
            this.Show();
            f7.ShowDialog();
            this.Close();
        }
        




    }
    }




    
