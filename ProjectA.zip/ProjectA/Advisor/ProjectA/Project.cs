﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project

{
    public partial class Project : Form
    {
        public Project()
        {
            InitializeComponent();
            comboBoxid.Items.Add("Group Id");
            comboBoxid.Items.Add("Project Id");
            comboBoxid.Items.Add("Student Id");
            comboBoxid.Items.Add("Evaluation Id");
            comboBoxid.Items.Add("Advisor Id");
        }

        //SQL Connection for Database
        SqlConnection conn = new SqlConnection(@"Data Source=SABANOOR\SABA;Initial Catalog=ProjectA;Integrated Security=True; MultipleActiveResultSets = True");



        //Display data in the Gridview
        private void Display_Data()
        {
            //Connection Open

            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "select * from Project";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter dataadp = new SqlDataAdapter(cmd);
            dataadp.Fill(dt);
            dataGridView1.DataSource = dt;
            //Connection Close
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }

        }

        //Save Button in which we insert a data and save it
        private void btnSave_Click(object sender, EventArgs e)
        {
            //Connection Open
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT into Project(Description, Title) values ('" + txtDescription.Text + "' , '" + txtTitle.Text + "')";
            cmd.ExecuteNonQuery();
            conn.Close();
            txtDescription.Text = "";
            txtTitle.Text = "";

            Display_Data();
            MessageBox.Show("Data Inserted");
            //Connection Close
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }

        }


        private void Project_Load(object sender, EventArgs e)
        {

        }

        //Display button in which we show a data
        private void btnDisplaydata_Click(object sender, EventArgs e)
        {
            Display_Data();
        }

       //Delete button in which we can delete a data  in a row
        private void button2_Click(object sender, EventArgs e)
        {
            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "DELETE from Project where  Title ='" + txtTitle.Text + "'";
            if (MessageBox.Show("Do You want to delete it", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MessageBox.Show("DATA IS DELETED");
            }
            else
            {
                MessageBox.Show("Row not deleted", "Remove row", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            cmd.ExecuteNonQuery();
            txtDescription.Text = "";
            txtTitle.Text = "";
            Display_Data();
            //Connection Close
            conn.Close();
        }

        //Update button in which we can update a name and value in a row
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Update Project set Description = '" + this.txtDescription.Text + "' ,Title = '" + this.txtTitle.Text + "'  where title = '" + this.txtTitle.Text + "'";


            cmd.ExecuteNonQuery();
            //Connection Close
            conn.Close();
            txtDescription.Text = "";
            txtTitle.Text = "";

            Display_Data();
            MessageBox.Show("DATA IS Updated");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Advisor.Group_Project f7 = new Advisor.Group_Project();
            this.Show();
            f7.ShowDialog();
            this.Close();
        }
    }
}
