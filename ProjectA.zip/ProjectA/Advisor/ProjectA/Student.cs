﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Student
{
    public partial class Student : Form
    {
        public Student()
        {

            InitializeComponent();
            comboBoxGender.Items.Add("Male");
            comboBoxGender.Items.Add("Female");

        }

        //SQL Connection for database
        SqlConnection conn = new SqlConnection(@"Data Source=SABANOOR\SABA;Initial Catalog=ProjectA;Integrated Security=True;  MultipleActiveResultSets = True");
        private object email;

        public object Id { get; private set; }

      

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {



        }
        //Display Data in the GRidview
        private void Display_Data()
        {
            //Connection Open
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            //join Student ON Person.Id = Student.Id
            //join Student ON Person.Id = Student.Id
            //, Student.RegistrationNo
            cmd.CommandText = "select Person.Id,Person.FirstName, Person.LastName, Person.Contact , Person.Email ,Person.DateOfBirth , Person.Gender , Student.RegistrationNo  from Person join Student ON Person.Id = Student.Id ";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter dataadp = new SqlDataAdapter(cmd);
            dataadp.Fill(dt);
            dataGridView1.DataSource = dt;
            //Connection Close
            conn.Close();
        }

        //Display Button in which we show a data
        private void btnDisplaydata_Click_1(object sender, EventArgs e)
        {
            Display_Data();
        }

        //Save Button in which we insert a data and save it
        private void btnSave_Click(object sender, EventArgs e)
        {
            //Connection OPen
            conn.Open();




            string congo = comboBoxGender.SelectedItem.ToString();

            string genderValue = "select Id FROM Lookup WHERE Category = 'Gender' AND value ='" + congo + "'";
            SqlCommand genderInt = new SqlCommand(genderValue, conn);
            int value = 0;
            SqlDataReader reader = genderInt.ExecuteReader();
            // genderInt.ExecuteNonQuery();
            while (reader.Read())
            {
                value = int.Parse(reader[0].ToString());
            }

            //int gender = Convert.ToInt32(genderInt.ExecuteScalar ());

            string per = "INSERT into Person(FirstName , LastName , Registration No, Contact , Email , DateOfBirth , Gender) values ('" + txtFirstName.Text + "' , '" + txtLastName.Text + "' , '" + txtDateofbirth.Text + "' , '" + txtEmail.Text + "' , '" + txtRegNo.Text + "' , '"+comboBoxGender +" ' , '" + value + "')";

            SqlCommand persi = new SqlCommand(per, conn);
            int ii = persi.ExecuteNonQuery();
            int value1 = 0;
            string query = "Select Id from Person where (Id = SCOPE_IDENTITY())";
            SqlCommand cmd = new SqlCommand(query, conn);
            var val = cmd.ExecuteScalar().ToString();
            value1 = int.Parse(val);
            string q = "insert into Student values('" + value1 + "','" + txtEmail.Text.ToString() + "')";
            SqlCommand cmd1 = new SqlCommand(q, conn);
            int j = cmd1.ExecuteNonQuery();

            //Connection Close
            conn.Close();
            Display_Data();
            MessageBox.Show("Data Inserted");
        }

        //Delete button in which we delete a data in a row
        private void btnDelete_Click_1(object sender, EventArgs e)
        {

        
        string del = string.Format("Delete From Person Where Id = '{0}'", Id);
            SqlCommand delete = new SqlCommand(del);
            if (MessageBox.Show("Do You want to delete it", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MessageBox.Show("DATA IS DELETED");
            }
            else
            {
                MessageBox.Show("Row not deleted", "Remove row", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            Display_Data();

        }

        //Update button in which we update a data in a row
        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            //Connection Open
            conn.Open();

            string genderValue = "select Id FROM Lookup WHERE Category = 'Gender' AND value ='" + comboBoxGender.Text.ToString() + "'";
            SqlCommand genderInt = new SqlCommand(genderValue, conn);
            int value = 0;
            SqlDataReader reader = genderInt.ExecuteReader();
            // genderInt.ExecuteNonQuery();
            while (reader.Read())
            {
                value = int.Parse(reader[0].ToString());
            }
            string query = string.Format("SELECT Id from Student Where RegistrationNo = '" + txtRegNo.Text + "'");
            SqlCommand cmd = new SqlCommand(query, conn);
            var val = cmd.ExecuteScalar().ToString();
            int value1 = int.Parse(val);
            // int id =int.Parse( cmd.ExecuteScalar());
            string per = "Update Person set FirstName ='" + txtFirstName.Text + "' ,  LastName= '" + txtLastName.Text + "' , Contact = '" + txtContact.Text + "', Email = '" + txtEmail.Text + "', DateOfBirth ='" + txtDateofbirth.Text + "', Gender = '" + value + "' WHERE Id= '" + value1 + "'";
            SqlCommand persi = new SqlCommand(per, conn);
            int i = persi.ExecuteNonQuery();
            // string st = "Update Student set RegistrationNo = '" + textBox1.Text + "' where Id ='"+Id+"'";
            if (MessageBox.Show("Do You want to Update it", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                MessageBox.Show("DATA IS Updated");
            }
            else
            {
                MessageBox.Show("Row not Updated", "Update row", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            // SqlCommand std = new SqlCommand(st, conn);
            // int ii = std.ExecuteNonQuery();

            //Connection Close
            conn.Close();
            Display_Data();
            MessageBox.Show("Data Updated");
        }

        private void btngroupstudent_Click_1(object sender, EventArgs e)
        {
            Advisor.GroupStudent f6 = new Advisor.GroupStudent();
            this.Show();
            f6.ShowDialog();
            this.Close();
        }
    }
}

